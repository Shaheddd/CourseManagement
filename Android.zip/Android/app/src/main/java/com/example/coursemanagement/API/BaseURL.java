package com.example.coursemanagement.API;

public class BaseURL {

    String URL = "http://192.168.8.102:9191/";

    public String APIBaseURL() {
        return URL;
    }


}
