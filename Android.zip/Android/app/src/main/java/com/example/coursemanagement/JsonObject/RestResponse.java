package com.example.coursemanagement.JsonObject;

public class RestResponse {

    private Message message;

    public RestResponse(Message message) {
        this.message = message;
    }

    public RestResponse() {
    }

    public Message getMessage() {
        return message;
    }

    public void setMessage(Message message) {
        this.message = message;
    }
}
